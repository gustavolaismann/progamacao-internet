//input
let inputNumberOne = document.querySelector("#inputNumberOne");
let inputNumberTwo = document.querySelector("#inputNumberTwo");
let inputNumberThree = document.querySelector("#inputNumberThree");
//result
let resultAritmetica = document.querySelector("#resultAritmetica");
let resultPonderada = document.querySelector("#resultPonderada");
let resultSumMedias = document.querySelector("#resultSumMedias");
let resultMediaMedia = document.querySelector("#resultMediaMedia");
//button
let btEnter = document.querySelector("#btEnter");

function getnumber(){
    return[
        Number(inputNumberOne.value),
        Number(inputNumberTwo.value),
        Number(inputNumberThree.value)
    ];
}
function aritmetica(){
    let [a, b, c] = getnumber();
    let mediaAritmetica = (a + b + c) / 3;
    return mediaAritmetica;

}

function ponderada(){
    let [a, b, c] = getnumber();
    let sumNumbers= (a*3) + (b*2) + (c*5);
    let sumPounds= 3+2+5
    let mediaPonderada= sumNumbers / sumPounds;
    return mediaPonderada;

}

function sumMedias(){
    let mediaAritmetica = aritmetica();
    let mediaPonderada = ponderada();

    let somaMedias = mediaAritmetica + mediaPonderada;
    return somaMedias;

}
function mediaMedia(){
   let medias = sumMedias();
   let mediaDasMedias= medias /2;
   return mediaDasMedias;
}

btEnter.onclick = function(){
    resultAritmetica.textContent = aritmetica();
    resultPonderada.textContent = ponderada();
    resultMediaMedia.textContent = mediaMedia();
    resultSumMedias.textContent = sumMedias();
}
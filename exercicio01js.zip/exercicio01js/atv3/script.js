let inputBalance= document.querySelector("#inputBalance");
let enter = document.querySelector("#enter");
let result = document.querySelector("#result");

function adjust(){
    let balance = Number(inputBalance.value);
    let tax = balance * 0.01;
    let adjustedBalance = balance - tax;

    result.textContent = adjustedBalance.toFixed(2);
}

enter.onclick = function (){
    adjust()
}
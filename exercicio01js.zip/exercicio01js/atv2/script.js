let inputPrice = document.querySelector("#inputPrice");
let inputQntd = document.querySelector("#inputQntd");
let btEnter = document.querySelector("#btEnter");
let result = document.querySelector("#result");

function calc(){
    let price = Number(inputPrice.value);
    let qntd = Number(inputQntd.value);
    let finalPrice = price * qntd;

    result.textContent = "R$" + finalPrice.toFixed(2);
}

btEnter.onclick = function(){
    calc();
}
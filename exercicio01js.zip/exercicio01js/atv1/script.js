let inputPaid = document.querySelector("#inputPaid");
let inputPrice = document.querySelector("#inputPrice");
let result = document.querySelector("#result");
let enter = document.querySelector("#enter");


function change(){
    let paid = Number(inputPaid.value);
    let price = Number(inputPrice.value);
    let changeValue = paid - price;

    result.textContent = changeValue;

}






enter.onclick = function(){
    change();
}

